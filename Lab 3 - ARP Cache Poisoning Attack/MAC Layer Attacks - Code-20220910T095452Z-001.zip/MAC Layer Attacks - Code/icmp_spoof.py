#!/usr/bin/python3
from scapy.all import *
print ("SENDING SPOOFED ICMP PACKET...")
IPLayer = IP()
IPLayer.src="10.0.2.54" 
IPLayer.dst="10.0.2.15"
ICMPpkt = ICMP()
pkt = IPLayer/ICMPpkt
pkt.show ()
send(pkt,verbose=0)
